﻿using UnityEngine;
using System.Collections;
using UnityEditor;
using System.IO;

public class AssetBundleBuilder
{
	private const string BUNDLE_BUILD_PATH = "Assets/AssetBundles";


	[MenuItem("Assets/Build All Asset Bundles for Android")]
	static void BuildAllAssetBundles()
	{
		// Clean current build directory
		DirectoryInfo info = new DirectoryInfo(BUNDLE_BUILD_PATH);
		FileInfo[] fileInfo = info.GetFiles();
		foreach (FileInfo file in fileInfo)
			file.Delete();

		// Build
		BuildPipeline.BuildAssetBundles(BUNDLE_BUILD_PATH, BuildAssetBundleOptions.None, BuildTarget.Android);

		// Remove unneeded files
		File.Delete(BUNDLE_BUILD_PATH + "/AssetBundles");
		File.Delete(BUNDLE_BUILD_PATH + "/AssetBundles.manifest");
	}
}