﻿using UnityEngine;
using System.Collections;
using System;

public class AssetBundleLoader : MonoBehaviour {

	public string bundleUrl;

	private const string ASSET_NAME = "tinker-prefab";

	IEnumerator Start()
	{
		if (bundleUrl == "")
			Debug.LogError("Missing bundle URL configuration");
		else
			yield return loadBundle();
	}

	private IEnumerator loadBundle()
	{
		Debug.Log("Downloading asset bundle: " + bundleUrl);
		using (WWW www = new WWW(bundleUrl))
		{
			yield return www;
			if (www.error != null)
				throw new Exception("Download of remote asset " + bundleUrl + " failed: " + www.error);
			// Check downloaded content type
			string contentType = "";
			bool hasContentType = www.responseHeaders.TryGetValue("content-type", out contentType);
			if (!hasContentType || !contentType.Contains("application/octet-stream"))
				throw new Exception("Downloaded file is not a Unity asset bundle (invalid content-type: "+ contentType +"): " + bundleUrl);
			// Extract bundle from downloaded content
			AssetBundle bundle = www.assetBundle;
			if (bundle == null)
				throw new Exception("Downloaded file is not a Unity asset bundle: "+ bundleUrl);
			// Extract prefab from bundle
			GameObject tinkerPrefab = bundle.LoadAsset<GameObject>(ASSET_NAME);
			if (tinkerPrefab == null)
				throw new Exception("Missing '"+ ASSET_NAME + "' game object in remote bundle: " + bundleUrl);
			// Check that the prefab has a box collider
			BoxCollider boxCollider = tinkerPrefab.GetComponent<BoxCollider>();
			if (boxCollider == null)
				throw new Exception("Missing Box Collider component on remote bundle: " + bundleUrl);
			// Instantiate prefab
			GameObject.Instantiate(tinkerPrefab);
			bundle.Unload(false);
		}
	}
}
