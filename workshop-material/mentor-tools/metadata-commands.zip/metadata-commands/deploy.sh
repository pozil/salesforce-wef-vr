java -cp "lib/*" com.poz.mdapi.commands.Deploy
